import { Routes } from '@angular/router';

export const DashboardRoutes: Routes = [
   {
      path: '',
      redirectTo: 'crm',
      pathMatch: 'full'
   },
   {
      path: '',
      children: [
         {
         path: 'saas',
         loadChildren: () =>
            import('./saas/saas.module').then((m) => m.SaasModule),
         },
         {
         path: '',
         loadChildren: () =>
            import('./crm/crm.module').then((m) => m.CrmModule),
         },
      ]
   }
];
