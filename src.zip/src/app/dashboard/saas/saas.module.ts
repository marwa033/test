import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SaasRoutingModule } from './saas-routing.module';
import { SaasComponent } from './saas.component';
@NgModule({
  declarations: [SaasComponent],
  imports: [CommonModule, SaasRoutingModule],
})
export class SaasModule { }
